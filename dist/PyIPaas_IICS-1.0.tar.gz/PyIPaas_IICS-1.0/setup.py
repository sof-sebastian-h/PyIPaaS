# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pyipaas_iics']

package_data = \
{'': ['*']}

install_requires = \
['pandas>=1.3.3,<2.0.0', 'requests>=2.26.0,<3.0.0']

setup_kwargs = {
    'name': 'pyipaas-iics',
    'version': '1.0',
    'description': 'This project allows you to automate job metadata collection and execution for any informatica cloud instance',
    'long_description': None,
    'author': 'Sebastian',
    'author_email': 'sebastian.hansen_vega@outlook.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
