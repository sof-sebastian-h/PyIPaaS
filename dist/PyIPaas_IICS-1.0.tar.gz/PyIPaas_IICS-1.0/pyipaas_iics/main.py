import sys
from MetaData_Class import IICS_Job_Metadata
from RunAJob_Class import IICS_Run_Job


##################   Parms   #######################
if len(sys.argv)    >1:
    project         = sys.argv[1]
    org             = sys.argv[2]
    user            = sys.argv[3]
    pwd             = int(sys.argv[4])

else :

    project = ['DnA (Walk)']
    org = 'dmr-us'
    user = 'DISPRE'
    pwd = 'HJKYkkd!23!'


####################################################


df = IICS_Job_Metadata(org=org,user=user,pwd=pwd,project_list=project,run_type=['TASKFLOW','MI_TASK','DSS']).job_id_list()
df['path']= df['path'].str.upper()
filter_daily_only = df['path'].str.contains('DAILY')
filter_exclude = df['path'] != 'TEMP_DONOTRUN/'
df =df[filter_daily_only &filter_exclude]
#df['type'] = df.apply(lambda x: x['type'],axis = 1)
#df['RUN_A_JOB'] = df.apply(lambda x : IICS_Run_Job(org=org,user=user,pwd=pwd,project_list=project,run_type=x['type'],jobid= x['id']).orchestrate,axis=1)
#df.to_parquet(rf'C:\Users\545001\Documents\Prerelease Testing\{project}.parquet')
print(df)
